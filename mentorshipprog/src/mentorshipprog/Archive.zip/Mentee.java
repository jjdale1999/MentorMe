package mentorshipprog;

class Mentee {

}
